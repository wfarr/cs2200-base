#include "gt16/archgt16.h"
#define ARCHCLASS ArchGT16
